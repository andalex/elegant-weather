
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'andersonalex666',
  applicationName: 'elegant-weather',
  appUid: '7jvdF4Cx7228VRwKfR',
  orgUid: 'ba823fec-4900-428b-b174-60bde75902a0',
  deploymentUid: '278d6f99-eedd-4734-b091-23004d3ed0b0',
  serviceName: 'elegant-weather-lambda',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '7.2.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'elegant-weather-lambda-dev-api', timeout: 6 };

try {
  const userHandler = require('./src/handlers/forecast.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}